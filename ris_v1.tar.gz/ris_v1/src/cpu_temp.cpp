// ROS node to determine the core temperatures
// ===========================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Quaternion.h>
#include <diagnostic_msgs/DiagnosticArray.h>
#include <diagnostic_msgs/DiagnosticStatus.h>
#include <diagnostic_msgs/KeyValue.h>
#include<std_msgs/String.h>
int count=0;
int fan1=0;
int fan2=0;
int fan3=0;
int fan4=0;

    ros::Publisher pub;
	ros::Publisher pub1;
void callbackCPUTemp(const diagnostic_msgs::DiagnosticArray temp);

void callbackCoolTemp(const geometry_msgs::QuaternionConstPtr &cool)
{
fan1=cool->x;
fan2=cool->y;
fan3=cool->z;
fan4=cool->w;
} 


void callbackCPUTemp(const diagnostic_msgs::DiagnosticArrayConstPtr &temp)
{
 geometry_msgs::Vector3 tmp;
geometry_msgs::Vector3 at;
   
char tmprtr[]= "hell";
tmprtr[0]= temp->status[0].values[1].value [0];
tmprtr[1]= temp->status[0].values[1].value[1];
tmprtr[2]= temp->status[0].values[2].value[0];
tmprtr[3]= temp->status[0].values[2].value[1];
float core1_temp=((tmprtr[0]-48)*10)+(tmprtr[1]-48);
float core2_temp=((tmprtr[2]-48)*10)+(tmprtr[3]-48);
float fan=0;
ROS_INFO_STREAM( "Recieved: "<<"core1:" << core1_temp);
ROS_INFO_STREAM( "Recieved: "<<"core2:" << core2_temp);
if (fan3>=1 || fan4>=1)
{
tmp.x=((0.025*((core1_temp-5)-80))+1); //min_temp=40 and max_temp=80
tmp.y=((0.025*((core2_temp-5)-80))+1);
tmp.z=fan;
}
else
{
tmp.x=((0.025*(core1_temp-80))+1); //min_temp=40 and max_temp=80
tmp.y=((0.025*(core2_temp-80))+1);
tmp.z=fan;
}
pub.publish(tmp);
ros::spinOnce();
ROS_INFO_STREAM( "Recieved: "<<"core1:" << tmp.x);
ROS_INFO_STREAM( "Recieved: "<<"core2:" << tmp.y);
}
int main(int argc, char **argv)
{
    ros::init(argc, argv, "cpu_temp");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Vector3>("/Temperature", 10);
	ros::Subscriber sub = nh.subscribe("/diagnostics", 100, callbackCPUTemp);
	ros::spin();
    return 0;
}

// ROS node to calculate Energy consumed by the robot on the basis of power consumption over time
// ==============================================================================================

#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/Vector3.h>

	ros::Publisher pub;
    void callbackTorque(const sensor_msgs::JointState torq);
    double initial_energy=5000;
    float Left_joint_power;
    float Right_joint_power;
	float gripper_power;
    double energy_left=0;
    double z =5000;

 double energy(double p1, double p2, double p3, double& z)
{
    double consumed_energy=0;
if(p1<0){
p1=-p1;}
if(p2<0){
p2=-p2;}  
	consumed_energy=((p1+p2)*0.05 +p3);
    initial_energy=z;
double energy = initial_energy-consumed_energy;
    z=energy;
    return energy;
}

void callbackTorque(const sensor_msgs::JointStateConstPtr &joint)
{
 geometry_msgs::Vector3 msg;
  
    float leftTorque = joint->effort[1]; //Torque of left motor
    float rightTorque = joint->effort[2];//Torque of right motor
	
    Left_joint_power= ((joint->velocity[0]*joint->effort[0])/0.07);
    Right_joint_power= ((joint->velocity[1]*joint->effort[1])/0.07);
	gripper_power=(joint->velocity[4]*joint->effort[4]);
	
	
   
    ROS_INFO("Left_joint_vel:%f  Right_joint_vel:%f", joint->velocity[0], joint->velocity[1]);  
    ROS_INFO("Left_joint_torq:%f  Right_joint_torq:%f", joint->effort[0], joint->effort[1]);
    ROS_INFO("Left_joint_pow:%f  Right_joint_pow:%f", Left_joint_power, Right_joint_power);
    energy_left=energy(Left_joint_power,Right_joint_power,gripper_power,z);
    ROS_INFO("Energy_remained:%f",energy_left);
  z=energy_left; 
if (energy_left<2000)
{ROS_INFO("Energy_is_getting_low");} 
msg.x=Left_joint_power;
msg.y=Right_joint_power;
msg.z=energy_left;
pub.publish(msg);
 }
int main(int argc, char **argv)
{
    ros::init(argc, argv, "energy");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Vector3>("/Energy", 10);
    ros::Subscriber sub = nh.subscribe("/joint_state", 10, callbackTorque);
    ros::spin();
    return 0;
}

// ROS node to mature dendtritic cells for the stimulation of T-cells of adaptive immunity
// =======================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/JointState.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Pose.h>


    ros::Publisher pub;
    float tmp_core1=0; float tmp_core2=0;
	float count=0;
	float check=0;
	float leftTorque=0;
	float rightTorque=0;

float MDC=0;
float inf;
void callbackInfo_motor(const sensor_msgs::JointStateConstPtr &trq)
{
	
	leftTorque = trq->effort[1];
	rightTorque = trq->effort[2];
}

void callbackinflammation(const geometry_msgs::PoseConstPtr &infl)
{inf=infl->position.y;
}
void callbackDendriticCell(const geometry_msgs::Vector3ConstPtr &value)
{
    	geometry_msgs::Vector3 dc;
	tmp_core1=value->x; 
	tmp_core2=value->y; 
	ROS_INFO("tmp_core1:%f", tmp_core1);
	ROS_INFO("tmp_core2:%f", tmp_core2);
         if (tmp_core1 > 0.90 || tmp_core2 > 0.90 || leftTorque > 0.2 || rightTorque >0.2)
	{count++;
	check=0+count;
	ROS_INFO("Count:%f", check);
	ROS_INFO("DCs are maturing");
	if(check>2)
{	ROS_INFO("DCs are ready to activate T Cells");
        MDC =MDC +1;
	ROS_INFO("DC:%f", MDC);
	dc.x = MDC;
	dc.y=count;
	pub.publish(dc);
	ROS_INFO("handover to adaptive immune system");
	ros::spinOnce();
}
}		
	if (tmp_core1<0.90 && tmp_core2<0.90)
{
	count=0;
	MDC=0;
	
}
       	dc.y=3*count;
	pub.publish(dc);
	ros::spinOnce();
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "DendritiCell");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Vector3>("/DC", 100);
    ros::Subscriber sub1 = nh.subscribe("/Temperature", 10, callbackDendriticCell);
	ros::Subscriber sub = nh.subscribe("/Inflammation", 10, callbackinflammation);
	ros::Subscriber sub2 = nh.subscribe("/joint_state", 10, callbackInfo_motor);
    ros::spin();
    return 0;
}


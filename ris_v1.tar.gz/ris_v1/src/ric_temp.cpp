// ROS node to mobilize Reactive Immune Cells of Innate Immunity against fault to perform recovery actions
// =======================================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Quaternion.h>
float core1_temp, core2_temp;

 ros::Publisher pub;
 ros::Publisher pub1;
void callbackCPUTemp(const geometry_msgs::Vector3 temp);

void callbackCPUTemp(const geometry_msgs::Vector3ConstPtr &temp)
{
 geometry_msgs::Vector3 tmp;
geometry_msgs::Vector3 at;
	core1_temp=temp->x;
	core2_temp=temp->y;
if (core1_temp>=60 || core2_temp>=60)
{
tmp.x=((0.025*((core1_temp-5)-80))+1); //min_temp=40 and max_temp=80
tmp.y=((0.025*((core2_temp-5)-80))+1);
}
pub.publish(tmp);
ros::spinOnce();

if (core1_temp>=60 || core2_temp>=60)
{
at.x=core1_temp-5;
at.y=core2_temp-5;
}
else
{
at.x=core1_temp;
at.y=core2_temp;
}
pub1.publish(at);
ros::spinOnce();
 }
int main(int argc, char **argv)
{
    ros::init(argc, argv, "ReactiveImmuneCell_temp");
    ros::NodeHandle nh;
	ros::Subscriber sub = nh.subscribe("/Temperature", 100, callbackCPUTemp);
    pub = nh.advertise<geometry_msgs::Vector3>("/Temperature", 10);
	pub1 = nh.advertise<geometry_msgs::Vector3>("/AT", 10);
	ros::spin();
    return 0;
}
